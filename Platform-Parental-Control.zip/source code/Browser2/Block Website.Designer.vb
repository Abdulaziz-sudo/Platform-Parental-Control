﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Block_Website
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Block_Website))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.TextBox1 = New Bunifu.Framework.UI.BunifuMaterialTextbox()
        Me.Button2 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.Button4 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.Button3 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BunifuFlatButton1 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label1.Location = New System.Drawing.Point(473, 65)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(180, 25)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Website To Block"
        '
        'ListBox1
        '
        Me.ListBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(5, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(30, Byte), Integer))
        Me.ListBox1.ForeColor = System.Drawing.Color.DodgerBlue
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.Location = New System.Drawing.Point(0, 2)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(355, 277)
        Me.ListBox1.TabIndex = 5
        '
        'TextBox1
        '
        Me.TextBox1.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TextBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.TextBox1.ForeColor = System.Drawing.Color.MediumAquamarine
        Me.TextBox1.HintForeColor = System.Drawing.Color.DodgerBlue
        Me.TextBox1.HintText = "put the website"
        Me.TextBox1.isPassword = False
        Me.TextBox1.LineFocusedColor = System.Drawing.Color.FromArgb(CType(CType(205, Byte), Integer), CType(CType(81, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.TextBox1.LineIdleColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(125, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.TextBox1.LineMouseHoverColor = System.Drawing.Color.FromArgb(CType(CType(205, Byte), Integer), CType(CType(81, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.TextBox1.LineThickness = 3
        Me.TextBox1.Location = New System.Drawing.Point(397, 138)
        Me.TextBox1.Margin = New System.Windows.Forms.Padding(4)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(369, 41)
        Me.TextBox1.TabIndex = 8
        Me.TextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'Button2
        '
        Me.Button2.Activecolor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(139, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.Button2.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(125, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button2.BorderRadius = 0
        Me.Button2.ButtonText = "Clear File Delete"
        Me.Button2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button2.DisabledColor = System.Drawing.Color.Gray
        Me.Button2.Font = New System.Drawing.Font("Franklin Gothic Medium", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Iconcolor = System.Drawing.Color.Transparent
        Me.Button2.Iconimage = Nothing
        Me.Button2.Iconimage_right = Nothing
        Me.Button2.Iconimage_right_Selected = Nothing
        Me.Button2.Iconimage_Selected = Nothing
        Me.Button2.IconMarginLeft = 0
        Me.Button2.IconMarginRight = 0
        Me.Button2.IconRightVisible = True
        Me.Button2.IconRightZoom = 0R
        Me.Button2.IconVisible = True
        Me.Button2.IconZoom = 90.0R
        Me.Button2.IsTab = False
        Me.Button2.Location = New System.Drawing.Point(624, 285)
        Me.Button2.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Button2.Name = "Button2"
        Me.Button2.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(125, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Button2.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(205, Byte), Integer), CType(CType(81, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Button2.OnHoverTextColor = System.Drawing.Color.White
        Me.Button2.selected = False
        Me.Button2.Size = New System.Drawing.Size(142, 51)
        Me.Button2.TabIndex = 21
        Me.Button2.Text = "Clear File Delete"
        Me.Button2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Button2.Textcolor = System.Drawing.Color.White
        Me.Button2.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'Button4
        '
        Me.Button4.Activecolor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(139, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.Button4.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(125, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Button4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button4.BorderRadius = 0
        Me.Button4.ButtonText = "Read File History Blocked"
        Me.Button4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button4.DisabledColor = System.Drawing.Color.Gray
        Me.Button4.Font = New System.Drawing.Font("Franklin Gothic Medium", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.Iconcolor = System.Drawing.Color.Transparent
        Me.Button4.Iconimage = Nothing
        Me.Button4.Iconimage_right = Nothing
        Me.Button4.Iconimage_right_Selected = Nothing
        Me.Button4.Iconimage_Selected = Nothing
        Me.Button4.IconMarginLeft = 0
        Me.Button4.IconMarginRight = 0
        Me.Button4.IconRightVisible = True
        Me.Button4.IconRightZoom = 0R
        Me.Button4.IconVisible = True
        Me.Button4.IconZoom = 90.0R
        Me.Button4.IsTab = False
        Me.Button4.Location = New System.Drawing.Point(13, 285)
        Me.Button4.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Button4.Name = "Button4"
        Me.Button4.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(125, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Button4.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(205, Byte), Integer), CType(CType(81, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Button4.OnHoverTextColor = System.Drawing.Color.White
        Me.Button4.selected = False
        Me.Button4.Size = New System.Drawing.Size(127, 51)
        Me.Button4.TabIndex = 22
        Me.Button4.Text = "Read File History Blocked"
        Me.Button4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Button4.Textcolor = System.Drawing.Color.White
        Me.Button4.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'Button3
        '
        Me.Button3.Activecolor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(139, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.Button3.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(125, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button3.BorderRadius = 0
        Me.Button3.ButtonText = "Delete Website From Blocked"
        Me.Button3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button3.DisabledColor = System.Drawing.Color.Gray
        Me.Button3.Font = New System.Drawing.Font("Franklin Gothic Medium", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.Iconcolor = System.Drawing.Color.Transparent
        Me.Button3.Iconimage = Nothing
        Me.Button3.Iconimage_right = Nothing
        Me.Button3.Iconimage_right_Selected = Nothing
        Me.Button3.Iconimage_Selected = Nothing
        Me.Button3.IconMarginLeft = 0
        Me.Button3.IconMarginRight = 0
        Me.Button3.IconRightVisible = True
        Me.Button3.IconRightZoom = 0R
        Me.Button3.IconVisible = True
        Me.Button3.IconZoom = 90.0R
        Me.Button3.IsTab = False
        Me.Button3.Location = New System.Drawing.Point(204, 285)
        Me.Button3.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Button3.Name = "Button3"
        Me.Button3.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(125, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Button3.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(205, Byte), Integer), CType(CType(81, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Button3.OnHoverTextColor = System.Drawing.Color.White
        Me.Button3.selected = False
        Me.Button3.Size = New System.Drawing.Size(140, 51)
        Me.Button3.TabIndex = 23
        Me.Button3.Text = "Delete Website From Blocked"
        Me.Button3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Button3.Textcolor = System.Drawing.Color.White
        Me.Button3.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BunifuFlatButton1
        '
        Me.BunifuFlatButton1.Activecolor = System.Drawing.Color.LightCoral
        Me.BunifuFlatButton1.BackColor = System.Drawing.Color.YellowGreen
        Me.BunifuFlatButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BunifuFlatButton1.BorderRadius = 0
        Me.BunifuFlatButton1.ButtonText = "Block Website"
        Me.BunifuFlatButton1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuFlatButton1.DisabledColor = System.Drawing.Color.Gray
        Me.BunifuFlatButton1.Iconcolor = System.Drawing.Color.Transparent
        Me.BunifuFlatButton1.Iconimage = CType(resources.GetObject("BunifuFlatButton1.Iconimage"), System.Drawing.Image)
        Me.BunifuFlatButton1.Iconimage_right = Nothing
        Me.BunifuFlatButton1.Iconimage_right_Selected = Nothing
        Me.BunifuFlatButton1.Iconimage_Selected = Nothing
        Me.BunifuFlatButton1.IconMarginLeft = 0
        Me.BunifuFlatButton1.IconMarginRight = 0
        Me.BunifuFlatButton1.IconRightVisible = True
        Me.BunifuFlatButton1.IconRightZoom = 0R
        Me.BunifuFlatButton1.IconVisible = True
        Me.BunifuFlatButton1.IconZoom = 90.0R
        Me.BunifuFlatButton1.IsTab = False
        Me.BunifuFlatButton1.Location = New System.Drawing.Point(437, 285)
        Me.BunifuFlatButton1.Name = "BunifuFlatButton1"
        Me.BunifuFlatButton1.Normalcolor = System.Drawing.Color.YellowGreen
        Me.BunifuFlatButton1.OnHovercolor = System.Drawing.Color.Teal
        Me.BunifuFlatButton1.OnHoverTextColor = System.Drawing.Color.White
        Me.BunifuFlatButton1.selected = False
        Me.BunifuFlatButton1.Size = New System.Drawing.Size(154, 51)
        Me.BunifuFlatButton1.TabIndex = 24
        Me.BunifuFlatButton1.Text = "Block Website"
        Me.BunifuFlatButton1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BunifuFlatButton1.Textcolor = System.Drawing.Color.White
        Me.BunifuFlatButton1.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'Block_Website
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(5, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(30, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(779, 338)
        Me.Controls.Add(Me.BunifuFlatButton1)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.ListBox1)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Block_Website"
        Me.Text = " "
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As Label
    Friend WithEvents ListBox1 As ListBox
    Friend WithEvents TextBox1 As Bunifu.Framework.UI.BunifuMaterialTextbox
    Friend WithEvents Button2 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents Button4 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents Button3 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents BunifuFlatButton1 As Bunifu.Framework.UI.BunifuFlatButton
End Class
