﻿Imports System.ComponentModel
Imports System.IO
Public Class frmFavorites
    'This form is used to edit the url favorites list.
    '
    'The url to add to the favorites
    Dim url As String
    '
    'Will hold the result of a possible invalid url
    Dim dialog As DialogResult
    Private Sub frmFavoritesEdit_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        '
        '
        Dim cnt As Integer = My.Settings.Bookmarks_Menu.Count
        Dim x As Integer

        For x = 0 To cnt - 1
            lstBookmarks.Items.Add(My.Settings.Bookmarks_Menu.Item(x))

        Next

        Me.Text = "Bookmarks Total: " & cnt

    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs)

        Try

            url = InputBox("Enter the URL to add to your Bookmarks list..." &
                vbNewLine & vbNewLine & "Leave out the Http://", "  Add URL", "www.")

            Dim h As New Net.IPHostEntry

            h = Net.Dns.GetHostEntry(url)

            dialog = Windows.Forms.DialogResult.Yes

            'If Not url = "" OrElse Nothing Then

            'lstFavorites.Items.Add(url)
            'My.Settings.Favorites_Menu.Add(url)
            'frmMain.tsBtnFavorites.DropDownItems.Add(url)

            'End If
            '
        Catch exc As Net.Sockets.SocketException

            dialog = MessageBox.Show(exc.Message & vbNewLine & vbNewLine &
                "Do you want to add the url anyways?", "  Possible Problem",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Warning)

        Finally
            '
            '
            If Not url = "" OrElse Nothing Then
                '
                If dialog = Windows.Forms.DialogResult.Yes Then
                    '
                    '
                    lstBookmarks.Items.Add(url)
                    '
                    My.Settings.Bookmarks_Menu.Add(url)
                    '
                    Browser.tsBtnBookmarks.DropDownItems.Add(url)
                    '
                    '
                End If
                '
            End If
            '
            '
        End Try

        'MsgBox(a.ToString)

        'Exit Sub

        'Dim re As New Regex("^(http|ftp)://(www\.)?.+\.$") '(com|net|org)$")
        'Dim re As New Regex("^(http|ftp)://(www\.)?.+\.$")
        'Dim mc As MatchCollection = re.Matches("") 'url)

        'If mc.Count > 0 Then

        'MsgBox("ok")

        'if validation passed so do further codes here
        'Else

        'MsgBox("not ok")

        'Validation faied so write your error coding here..
        'End If
    End Sub


    Private Sub btnRemove_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        lstBookmarks.Items.Remove(lstBookmarks.SelectedItem)

    End Sub

    Private Sub btnRemoveAll_Click(sender As Object, e As EventArgs)
        lstBookmarks.Items.Clear()
        File.Delete("C:\browser\favourite.txt")
    End Sub
    Private Sub cmMnuRemoveAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmMnuRemoveAll.Click

        'btnRemoveAll.PerformClick()

    End Sub


    Private Sub btnClose_Click(sender As Object, e As EventArgs)
        File.Delete("C:\browser\favourite.txt")

        For Each link As String In lstBookmarks.Items
            File.AppendAllText("C:\browser\favourite.txt", link & vbNewLine)

        Next
        Me.Visible = False
    End Sub

    Private Sub frmFavorites_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs)
        My.Computer.Clipboard.SetText("" & lstBookmarks.Text)
    End Sub

    Private Sub frmFavorites_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs)
        Dim data As String() = IO.File.ReadAllLines("C:\browser\favourite.txt")
        For i As Integer = 0 To data.Count - 1
            lstBookmarks.Items.Add(data(i))
        Next
    End Sub

    Private Sub BunifuFlatButton1_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton1.Click
        Try

            url = InputBox("Enter the URL to add to your Bookmarks list..." &
                vbNewLine & vbNewLine & "Leave out the Http://", "  Add URL", "www.")

            Dim h As New Net.IPHostEntry

            h = Net.Dns.GetHostEntry(url)

            dialog = Windows.Forms.DialogResult.Yes

            'If Not url = "" OrElse Nothing Then

            'lstFavorites.Items.Add(url)
            'My.Settings.Favorites_Menu.Add(url)
            'frmMain.tsBtnFavorites.DropDownItems.Add(url)

            'End If
            '
        Catch exc As Net.Sockets.SocketException

            dialog = MessageBox.Show(exc.Message & vbNewLine & vbNewLine &
                "Do you want to add the url anyways?", "  Possible Problem",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Warning)

        Finally
            '
            '
            If Not url = "" OrElse Nothing Then
                '
                If dialog = Windows.Forms.DialogResult.Yes Then
                    '
                    '
                    lstBookmarks.Items.Add(url)
                    '
                    My.Settings.Bookmarks_Menu.Add(url)
                    '
                    Browser.tsBtnBookmarks.DropDownItems.Add(url)
                    '
                    '
                End If
                '
            End If
            '
            '
        End Try

        'MsgBox(a.ToString)

        'Exit Sub

        'Dim re As New Regex("^(http|ftp)://(www\.)?.+\.$") '(com|net|org)$")
        'Dim re As New Regex("^(http|ftp)://(www\.)?.+\.$")
        'Dim mc As MatchCollection = re.Matches("") 'url)

        'If mc.Count > 0 Then

        'MsgBox("ok")

        'if validation passed so do further codes here
        'Else

        'MsgBox("not ok")

        'Validation faied so write your error coding here..
        'End If
    End Sub

    Private Sub BunifuFlatButton6_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton6.Click
        Dim data As String() = IO.File.ReadAllLines("C:\browser\favourite.txt")
        For i As Integer = 0 To data.Count - 1
            lstBookmarks.Items.Add(data(i))
        Next
    End Sub

    Private Sub BunifuFlatButton5_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton5.Click
        My.Computer.Clipboard.SetText("" & lstBookmarks.Text)
    End Sub

    Private Sub BunifuFlatButton4_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton4.Click
        lstBookmarks.Items.Remove(lstBookmarks.SelectedItem)
    End Sub

    Private Sub BunifuFlatButton3_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton3.Click
        lstBookmarks.Items.Clear()
        File.Delete("C:\browser\favourite.txt")
    End Sub

    Private Sub BunifuFlatButton2_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton2.Click
        File.Delete("C:\browser\favourite.txt")

        For Each link As String In lstBookmarks.Items
            File.AppendAllText("C:\browser\favourite.txt", link & vbNewLine)

        Next
        Me.Visible = False
    End Sub

    Private Sub lstBookmarks_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lstBookmarks.SelectedIndexChanged

    End Sub
End Class