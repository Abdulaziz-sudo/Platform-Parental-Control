﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Browser
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Browser))
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.NewWindowToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.EditToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UndoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RedoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.toolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.CutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CopyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PasteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.toolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator()
        Me.SelectAllToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FatherLoginToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsBtnBookmarks = New System.Windows.Forms.ToolStripDropDownButton()
        Me.tsMnuAddBookmarks = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsMnuRemove = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem3 = New System.Windows.Forms.ToolStripSeparator()
        Me.tsMnuManualAdd = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator7 = New System.Windows.Forms.ToolStripSeparator()
        Me.tsMnuAutoLoadBookmarks = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsMnuOpenNew = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripSeparator()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ContentsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.toolStripSeparator5 = New System.Windows.Forms.ToolStripSeparator()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStrip2 = New System.Windows.Forms.ToolStrip()
        Me.btnBack = New System.Windows.Forms.ToolStripButton()
        Me.btnforward = New System.Windows.Forms.ToolStripButton()
        Me.btnReload = New System.Windows.Forms.ToolStripButton()
        Me.btnHome = New System.Windows.Forms.ToolStripButton()
        Me.btnDownloads = New System.Windows.Forms.ToolStripButton()
        Me.lblData = New System.Windows.Forms.ToolStripLabel()
        Me.txtUrl = New System.Windows.Forms.ToolStripTextBox()
        Me.cobSearchEngines = New System.Windows.Forms.ToolStripComboBox()
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.WebBrowser1 = New System.Windows.Forms.WebBrowser()
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.MenuStrip1.SuspendLayout()
        Me.ToolStrip2.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.Color.DarkGray
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NewWindowToolStripMenuItem1, Me.EditToolStripMenuItem, Me.FatherLoginToolStripMenuItem, Me.tsBtnBookmarks, Me.HelpToolStripMenuItem, Me.ExitToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1370, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'NewWindowToolStripMenuItem1
        '
        Me.NewWindowToolStripMenuItem1.Name = "NewWindowToolStripMenuItem1"
        Me.NewWindowToolStripMenuItem1.Size = New System.Drawing.Size(81, 20)
        Me.NewWindowToolStripMenuItem1.Text = "New Window"
        '
        'EditToolStripMenuItem
        '
        Me.EditToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.UndoToolStripMenuItem, Me.RedoToolStripMenuItem, Me.toolStripSeparator3, Me.CutToolStripMenuItem, Me.CopyToolStripMenuItem, Me.PasteToolStripMenuItem, Me.toolStripSeparator4, Me.SelectAllToolStripMenuItem})
        Me.EditToolStripMenuItem.Name = "EditToolStripMenuItem"
        Me.EditToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.EditToolStripMenuItem.Text = "&Edit"
        '
        'UndoToolStripMenuItem
        '
        Me.UndoToolStripMenuItem.Name = "UndoToolStripMenuItem"
        Me.UndoToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Z), System.Windows.Forms.Keys)
        Me.UndoToolStripMenuItem.Size = New System.Drawing.Size(139, 22)
        Me.UndoToolStripMenuItem.Text = "&Undo"
        '
        'RedoToolStripMenuItem
        '
        Me.RedoToolStripMenuItem.Name = "RedoToolStripMenuItem"
        Me.RedoToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Y), System.Windows.Forms.Keys)
        Me.RedoToolStripMenuItem.Size = New System.Drawing.Size(139, 22)
        Me.RedoToolStripMenuItem.Text = "&Redo"
        '
        'toolStripSeparator3
        '
        Me.toolStripSeparator3.Name = "toolStripSeparator3"
        Me.toolStripSeparator3.Size = New System.Drawing.Size(136, 6)
        '
        'CutToolStripMenuItem
        '
        Me.CutToolStripMenuItem.Image = CType(resources.GetObject("CutToolStripMenuItem.Image"), System.Drawing.Image)
        Me.CutToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.CutToolStripMenuItem.Name = "CutToolStripMenuItem"
        Me.CutToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.X), System.Windows.Forms.Keys)
        Me.CutToolStripMenuItem.Size = New System.Drawing.Size(139, 22)
        Me.CutToolStripMenuItem.Text = "Cu&t"
        '
        'CopyToolStripMenuItem
        '
        Me.CopyToolStripMenuItem.Image = CType(resources.GetObject("CopyToolStripMenuItem.Image"), System.Drawing.Image)
        Me.CopyToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.CopyToolStripMenuItem.Name = "CopyToolStripMenuItem"
        Me.CopyToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.C), System.Windows.Forms.Keys)
        Me.CopyToolStripMenuItem.Size = New System.Drawing.Size(139, 22)
        Me.CopyToolStripMenuItem.Text = "&Copy"
        '
        'PasteToolStripMenuItem
        '
        Me.PasteToolStripMenuItem.Image = CType(resources.GetObject("PasteToolStripMenuItem.Image"), System.Drawing.Image)
        Me.PasteToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.PasteToolStripMenuItem.Name = "PasteToolStripMenuItem"
        Me.PasteToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.V), System.Windows.Forms.Keys)
        Me.PasteToolStripMenuItem.Size = New System.Drawing.Size(139, 22)
        Me.PasteToolStripMenuItem.Text = "&Paste"
        '
        'toolStripSeparator4
        '
        Me.toolStripSeparator4.Name = "toolStripSeparator4"
        Me.toolStripSeparator4.Size = New System.Drawing.Size(136, 6)
        '
        'SelectAllToolStripMenuItem
        '
        Me.SelectAllToolStripMenuItem.Name = "SelectAllToolStripMenuItem"
        Me.SelectAllToolStripMenuItem.Size = New System.Drawing.Size(139, 22)
        Me.SelectAllToolStripMenuItem.Text = "Select &All"
        '
        'FatherLoginToolStripMenuItem
        '
        Me.FatherLoginToolStripMenuItem.Name = "FatherLoginToolStripMenuItem"
        Me.FatherLoginToolStripMenuItem.Size = New System.Drawing.Size(79, 20)
        Me.FatherLoginToolStripMenuItem.Text = "Father Login"
        '
        'tsBtnBookmarks
        '
        Me.tsBtnBookmarks.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsMnuAddBookmarks, Me.tsMnuRemove, Me.ToolStripMenuItem3, Me.tsMnuManualAdd, Me.ToolStripSeparator7, Me.tsMnuAutoLoadBookmarks, Me.tsMnuOpenNew, Me.ToolStripMenuItem1})
        Me.tsBtnBookmarks.ForeColor = System.Drawing.Color.Black
        Me.tsBtnBookmarks.ImageTransparentColor = System.Drawing.Color.Plum
        Me.tsBtnBookmarks.Name = "tsBtnBookmarks"
        Me.tsBtnBookmarks.ShowDropDownArrow = False
        Me.tsBtnBookmarks.Size = New System.Drawing.Size(62, 17)
        Me.tsBtnBookmarks.Text = "Bookmarks"
        Me.tsBtnBookmarks.ToolTipText = "Bookmarks"
        '
        'tsMnuAddBookmarks
        '
        Me.tsMnuAddBookmarks.Name = "tsMnuAddBookmarks"
        Me.tsMnuAddBookmarks.Size = New System.Drawing.Size(230, 22)
        Me.tsMnuAddBookmarks.Text = "Bookmark This Page"
        '
        'tsMnuRemove
        '
        Me.tsMnuRemove.Name = "tsMnuRemove"
        Me.tsMnuRemove.Size = New System.Drawing.Size(230, 22)
        Me.tsMnuRemove.Text = "Edit Bookmarks"
        '
        'ToolStripMenuItem3
        '
        Me.ToolStripMenuItem3.Name = "ToolStripMenuItem3"
        Me.ToolStripMenuItem3.Size = New System.Drawing.Size(227, 6)
        '
        'tsMnuManualAdd
        '
        Me.tsMnuManualAdd.Name = "tsMnuManualAdd"
        Me.tsMnuManualAdd.Size = New System.Drawing.Size(230, 22)
        Me.tsMnuManualAdd.Text = "Add Custom Bookmarks"
        '
        'ToolStripSeparator7
        '
        Me.ToolStripSeparator7.Name = "ToolStripSeparator7"
        Me.ToolStripSeparator7.Size = New System.Drawing.Size(227, 6)
        '
        'tsMnuAutoLoadBookmarks
        '
        Me.tsMnuAutoLoadBookmarks.Checked = True
        Me.tsMnuAutoLoadBookmarks.CheckOnClick = True
        Me.tsMnuAutoLoadBookmarks.CheckState = System.Windows.Forms.CheckState.Checked
        Me.tsMnuAutoLoadBookmarks.Name = "tsMnuAutoLoadBookmarks"
        Me.tsMnuAutoLoadBookmarks.Size = New System.Drawing.Size(230, 22)
        Me.tsMnuAutoLoadBookmarks.Text = "Load Bookmarks at Startup"
        '
        'tsMnuOpenNew
        '
        Me.tsMnuOpenNew.CheckOnClick = True
        Me.tsMnuOpenNew.Name = "tsMnuOpenNew"
        Me.tsMnuOpenNew.Size = New System.Drawing.Size(230, 22)
        Me.tsMnuOpenNew.Text = "Open Bookmarks in New Window"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(227, 6)
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ContentsToolStripMenuItem, Me.toolStripSeparator5, Me.AboutToolStripMenuItem})
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(40, 20)
        Me.HelpToolStripMenuItem.Text = "&Help"
        '
        'ContentsToolStripMenuItem
        '
        Me.ContentsToolStripMenuItem.Name = "ContentsToolStripMenuItem"
        Me.ContentsToolStripMenuItem.Size = New System.Drawing.Size(118, 22)
        Me.ContentsToolStripMenuItem.Text = "&Contents"
        '
        'toolStripSeparator5
        '
        Me.toolStripSeparator5.Name = "toolStripSeparator5"
        Me.toolStripSeparator5.Size = New System.Drawing.Size(115, 6)
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(118, 22)
        Me.AboutToolStripMenuItem.Text = "&About..."
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(45, 20)
        Me.ExitToolStripMenuItem.Text = "Close"
        '
        'ToolStrip2
        '
        Me.ToolStrip2.BackColor = System.Drawing.Color.FromArgb(CType(CType(205, Byte), Integer), CType(CType(81, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.ToolStrip2.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.btnBack, Me.btnforward, Me.btnReload, Me.btnHome, Me.btnDownloads, Me.lblData, Me.txtUrl, Me.cobSearchEngines})
        Me.ToolStrip2.Location = New System.Drawing.Point(0, 24)
        Me.ToolStrip2.Name = "ToolStrip2"
        Me.ToolStrip2.Size = New System.Drawing.Size(1370, 33)
        Me.ToolStrip2.TabIndex = 2
        Me.ToolStrip2.Text = "ToolStrip2"
        '
        'btnBack
        '
        Me.btnBack.AutoSize = False
        Me.btnBack.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.btnBack.Image = Global.Browser2.My.Resources.Resources.Backward
        Me.btnBack.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnBack.Name = "btnBack"
        Me.btnBack.Size = New System.Drawing.Size(50, 30)
        Me.btnBack.Text = "To Front"
        '
        'btnforward
        '
        Me.btnforward.AutoSize = False
        Me.btnforward.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.btnforward.Image = Global.Browser2.My.Resources.Resources.Forward
        Me.btnforward.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnforward.Name = "btnforward"
        Me.btnforward.Size = New System.Drawing.Size(50, 30)
        Me.btnforward.Text = "To Back"
        '
        'btnReload
        '
        Me.btnReload.AutoSize = False
        Me.btnReload.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.btnReload.Image = Global.Browser2.My.Resources.Resources.Capture2
        Me.btnReload.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnReload.Name = "btnReload"
        Me.btnReload.Size = New System.Drawing.Size(50, 30)
        Me.btnReload.Text = "Refresh"
        '
        'btnHome
        '
        Me.btnHome.AutoSize = False
        Me.btnHome.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.btnHome.Image = Global.Browser2.My.Resources.Resources._65_2561
        Me.btnHome.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnHome.Name = "btnHome"
        Me.btnHome.Size = New System.Drawing.Size(50, 30)
        Me.btnHome.Text = "Home"
        '
        'btnDownloads
        '
        Me.btnDownloads.AutoSize = False
        Me.btnDownloads.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.btnDownloads.Image = CType(resources.GetObject("btnDownloads.Image"), System.Drawing.Image)
        Me.btnDownloads.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnDownloads.Name = "btnDownloads"
        Me.btnDownloads.Size = New System.Drawing.Size(50, 30)
        Me.btnDownloads.Text = "Downloader"
        '
        'lblData
        '
        Me.lblData.ForeColor = System.Drawing.Color.White
        Me.lblData.Name = "lblData"
        Me.lblData.Size = New System.Drawing.Size(0, 30)
        '
        'txtUrl
        '
        Me.txtUrl.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.txtUrl.AutoSize = False
        Me.txtUrl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtUrl.Name = "txtUrl"
        Me.txtUrl.Size = New System.Drawing.Size(500, 21)
        '
        'cobSearchEngines
        '
        Me.cobSearchEngines.Name = "cobSearchEngines"
        Me.cobSearchEngines.Size = New System.Drawing.Size(121, 33)
        '
        'ImageList1
        '
        Me.ImageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit
        Me.ImageList1.ImageSize = New System.Drawing.Size(16, 16)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Transparent
        '
        'WebBrowser1
        '
        Me.WebBrowser1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.WebBrowser1.Location = New System.Drawing.Point(0, 57)
        Me.WebBrowser1.MinimumSize = New System.Drawing.Size(20, 20)
        Me.WebBrowser1.Name = "WebBrowser1"
        Me.WebBrowser1.ScriptErrorsSuppressed = True
        Me.WebBrowser1.Size = New System.Drawing.Size(1370, 586)
        Me.WebBrowser1.TabIndex = 3
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(61, 4)
        '
        'Browser
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(1370, 643)
        Me.Controls.Add(Me.WebBrowser1)
        Me.Controls.Add(Me.ToolStrip2)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Browser"
        Me.Text = "POKO"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ToolStrip2.ResumeLayout(False)
        Me.ToolStrip2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents EditToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents UndoToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents RedoToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents toolStripSeparator3 As ToolStripSeparator
    Friend WithEvents CutToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CopyToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PasteToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents toolStripSeparator4 As ToolStripSeparator
    Friend WithEvents SelectAllToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ContentsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents toolStripSeparator5 As ToolStripSeparator
    Friend WithEvents AboutToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStrip2 As ToolStrip
    Friend WithEvents btnforward As ToolStripButton
    Friend WithEvents btnDownloads As ToolStripButton
    Friend WithEvents btnReload As ToolStripButton
    Friend WithEvents btnBack As ToolStripButton
    Friend WithEvents btnHome As ToolStripButton
    Friend WithEvents ImageList1 As ImageList
    Friend WithEvents WebBrowser1 As WebBrowser
    Friend WithEvents cobSearchEngines As ToolStripComboBox
    Friend WithEvents lblData As ToolStripLabel
    Friend WithEvents FatherLoginToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents tsBtnBookmarks As ToolStripDropDownButton
    Friend WithEvents tsMnuAddBookmarks As ToolStripMenuItem
    Friend WithEvents tsMnuRemove As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem3 As ToolStripSeparator
    Friend WithEvents tsMnuManualAdd As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator7 As ToolStripSeparator
    Friend WithEvents tsMnuAutoLoadBookmarks As ToolStripMenuItem
    Friend WithEvents tsMnuOpenNew As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem1 As ToolStripSeparator
    Friend WithEvents NewWindowToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents ContextMenuStrip1 As ContextMenuStrip
    Friend WithEvents txtUrl As ToolStripTextBox
End Class
