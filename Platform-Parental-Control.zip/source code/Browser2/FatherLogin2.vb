﻿Public Class FatherLogin2
    Private Sub Button1_Click(sender As Object, e As EventArgs)
        History.Show()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs)
        Block_Website.Show()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs)
        Shutdown_Computer.Show()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs)
        alarm.Show()
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs)
        Hide()
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs)
        Form3.Show()
    End Sub

    Private Sub Button1k_Click(sender As Object, e As EventArgs) Handles Button1.Click
        History.Show()
    End Sub

    Private Sub BunifuFlatButton1_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Block_Website.Show()
    End Sub

    Private Sub BunifuFlatButton5_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Shutdown_Computer.Show()
    End Sub

    Private Sub BunifuFlatButton7_Click(sender As Object, e As EventArgs) Handles Button4.Click
        alarm.Show()
    End Sub

    Private Sub BunifuFlatButton4_Click(sender As Object, e As EventArgs) Handles Button6.Click
        Form3.Show()
    End Sub

    Private Sub BunifuFlatButton6_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Hide()
    End Sub
End Class