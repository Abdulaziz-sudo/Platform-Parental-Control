﻿Public Class Shutdown_Computer
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Label2.Text = Val(Label2.Text) + 1
        If Label2.Text = 560 Then
            Label1.Text = Val(Label1.Text) + 1
            Label2.Text = 0
        End If
        If TextBox2.Text = Label1.Text And TextBox2.Text = Label2.Text Then
            System.Diagnostics.Process.Start("shutdown", "-s -t 00")
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs)
        Timer1.Start()
    End Sub
    Private Sub Button2_Click(sender As Object, e As EventArgs)
        Hide()
    End Sub

    Private Sub Shutdown_Computer_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub BunifuFlatButton1_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton1.Click
        Timer1.Start()
    End Sub

    Private Sub BunifuFlatButton2_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton2.Click
        Hide()
    End Sub
End Class