﻿Imports System.Net
Imports System.IO

Public Class Browser
    Public Property Kays As Object

    Private Sub NewTabToolStripMenuItem_Click(sender As Object, e As EventArgs)
        WebBrowser1.Navigate("www.google.com")
    End Sub

    Private Sub ToolsToolStripMenuItem_Click(sender As Object, e As EventArgs)

    End Sub


    Private Sub ToolStripButton1_Click(sender As Object, e As EventArgs) Handles btnforward.Click
        WebBrowser1.GoForward()
    End Sub

    Private Sub ToolStripButton2_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        WebBrowser1.GoBack()
    End Sub

    Private Sub btnReload_Click(sender As Object, e As EventArgs) Handles btnReload.Click
        WebBrowser1.Refresh()
    End Sub

    Private Sub WebBrowser1_Navigated(sender As Object, e As WebBrowserNavigatedEventArgs) Handles WebBrowser1.Navigated
        txtUrl.Text = WebBrowser1.Url.ToString


        History.lstHistory.Items.Add(txtUrl.Text)
    End Sub

    Private Sub txtUrl_KeyUp(sender As Object, e As KeyEventArgs) Handles txtUrl.KeyUp
        If e.KeyCode = Keys.Enter Then
            WebBrowser1.Navigate(txtUrl.Text)
        End If
        If e.KeyData = Keys.Enter Then
            btnforward.PerformClick()
            e.SuppressKeyPress = True
        End If
    End Sub

    Private Sub WebBrowser1_DocumentCompleted_1(sender As Object, e As WebBrowserDocumentCompletedEventArgs)

    End Sub

    Private Sub txtUrl_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Browser_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        cobSearchEngines.Items.Add("Google")

        cobSearchEngines.SelectedIndex = 0

        WebBrowser1.Navigate("www.google.com")

        lblData.Text = Now

        Try
            For Each link As String In File.ReadLines("C:\browser\history.txt")
                History.lstHistory.Items.Add(link.ToString)
            Next
        Catch ex As Exception

        End Try
        System.IO.Directory.CreateDirectory("C:\browser")



    End Sub
    Private Sub web_DocumentTitleChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles WebBrowser1.DocumentTitleChanged
        Me.Text = "  " & WebBrowser1.DocumentTitle & " - POKO"
    End Sub

    Private Sub btnHome_Click(sender As Object, e As EventArgs) Handles btnHome.Click
        WebBrowser1.Navigate(My.Settings.homePage)
    End Sub

    Private Sub btntaibah_Click(sender As Object, e As EventArgs)
        WebBrowser1.Navigate(My.Settings.Taibah)
    End Sub

    Private Sub cobSearchEngines_Click(sender As Object, e As EventArgs) Handles cobSearchEngines.Click

    End Sub

    Private Sub MenuStrip1_ItemClicked(sender As Object, e As ToolStripItemClickedEventArgs) Handles MenuStrip1.ItemClicked

    End Sub

    Private Sub WebBrowser1_DocumentCompleted(sender As Object, e As WebBrowserDocumentCompletedEventArgs) Handles WebBrowser1.DocumentCompleted

    End Sub

    Private Sub HistoryToolStripMenuItem_Click(sender As Object, e As EventArgs)
        History.Show()

    End Sub

    Private Sub Browser_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        For Each link As String In History.lstHistory.Items
            File.AppendAllText("C:\browser\history.txt", link & vbNewLine)
        Next
    End Sub

    Private Sub FatherLoginToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles FatherLoginToolStripMenuItem.Click
        FatherLogin1.Show()
    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Dim myProcesss() As Process = System.Diagnostics.Process.GetProcessesByName("poko")
        For Each myKilll As Process In myProcesss
            myKilll.Kill()
        Next
    End Sub

    Private Sub UndoToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles UndoToolStripMenuItem.Click
        txtUrl.Undo()
    End Sub

    Private Sub RedoToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RedoToolStripMenuItem.Click
        txtUrl.ClearUndo()
    End Sub

    Private Sub CutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CutToolStripMenuItem.Click
        txtUrl.Cut()
    End Sub

    Private Sub CopyToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CopyToolStripMenuItem.Click
        txtUrl.Copy()
    End Sub

    Private Sub PasteToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PasteToolStripMenuItem.Click
        txtUrl.Paste()
    End Sub

    Private Sub SelectAllToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SelectAllToolStripMenuItem.Click
        txtUrl.SelectAll()
    End Sub

    Private Sub tsMnuAddBookmarks_Click(sender As Object, e As EventArgs) Handles tsMnuAddBookmarks.Click
        My.Settings.Bookmarks_Menu.Add(WebBrowser1.Url.AbsoluteUri)
        tsBtnBookmarks.DropDownItems.Add(WebBrowser1.Url.AbsoluteUri)
    End Sub

    Private Sub tsMnuRemove_Click(sender As Object, e As EventArgs) Handles tsMnuRemove.Click
        frmFavorites.Show(Me)
    End Sub

    Private Sub tsMnuManualAdd_Click(sender As Object, e As EventArgs) Handles tsMnuManualAdd.Click
        Dim fav As String = InputBox("What is the URL of the Website to add?", "  Add URL",
            "http://www.")
        If Not fav = Nothing Then
            My.Settings.Bookmarks_Menu.Add(fav)
            tsBtnBookmarks.DropDownItems.Add(fav)
        End If
    End Sub

    Private Sub tsMnuManualLoad_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub tsMnuAutoLoadBookmarks_Click(sender As Object, e As EventArgs) Handles tsMnuAutoLoadBookmarks.Click
        My.Settings.Bookmarks_AutoLoad = tsMnuAutoLoadBookmarks.Checked
    End Sub

    Private Sub tsMnuOpenNew_Click(sender As Object, e As EventArgs) Handles tsMnuOpenNew.Click
        My.Settings.Bookmarks_NewWindow = tsMnuOpenNew.Checked
        frmFavorites.Show()
    End Sub

    Private Sub AboutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AboutToolStripMenuItem.Click
        MsgBox("Team Coder Girls")
    End Sub

    Private Sub ContentsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ContentsToolStripMenuItem.Click
        MsgBox("NoN")
    End Sub

    Private Sub NewWindowToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles NewWindowToolStripMenuItem1.Click
        Dim newwindows As New Browser
        newwindows.Show()
    End Sub

    Private Sub ToolStrip2_ItemClicked(sender As Object, e As ToolStripItemClickedEventArgs) Handles ToolStrip2.ItemClicked

    End Sub

    Private Sub txtUrl_OnValueChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub btnDownloads_Click(sender As Object, e As EventArgs) Handles btnDownloads.Click
        Download.Show()
    End Sub

    Private Sub txtUrl_Click_1(sender As Object, e As EventArgs) Handles txtUrl.Click

    End Sub
End Class
