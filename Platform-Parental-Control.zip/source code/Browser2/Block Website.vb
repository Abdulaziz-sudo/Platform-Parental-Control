﻿Imports System.IO
Public Class Block_Website
    Dim path As String
    Dim sw As StreamWriter

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs)
        path = "C:\Windows\System32\drivers\etc\hosts"
        sw = New StreamWriter(path, True)
        Dim sitetoblock As String = (Environment.NewLine & "127.0.0.1 " & TextBox1.Text) 'has to be www.google.com | NOT: http://www.google.com/
        sw.Write(sitetoblock)
        sw.Close()
        MessageBox.Show("Site Blocked")
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs)
        ListBox1.Items.Clear()
        File.Delete("C:\Windows\System32\drivers\etc\hosts")
        MsgBox("UnBlocked Success")
    End Sub

    Private Sub ListBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListBox1.SelectedIndexChanged

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs)
        ListBox1.Items.Remove(ListBox1.SelectedItem)
        MsgBox("Deleted Success")
    End Sub

    Private Sub Block_Website_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        ' Never Lose History
        e.Cancel = True
        Me.Visible = False

        File.Delete("C:\Windows\System32\drivers\etc\hosts")

        For Each link As String In ListBox1.Items
            File.AppendAllText("C:\Windows\System32\drivers\etc\hosts", link & vbNewLine)

        Next
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs)
        Dim lines() As String = IO.File.ReadAllLines("C:\Windows\System32\drivers\etc\hosts")
        ListBox1.Items.AddRange(lines)
        MsgBox("Read Success")
    End Sub

    Private Sub Block_Website_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button1k_Click(sender As Object, e As EventArgs)
        path = "C:\Windows\System32\drivers\etc\hosts"
        sw = New StreamWriter(path, True)
        Dim sitetoblock As String = (Environment.NewLine & "127.0.0.1 " & TextBox1.Text) 'has to be www.google.com | NOT: http://www.google.com/
        sw.Write(sitetoblock)
        sw.Close()
        MessageBox.Show("Site Blocked")
    End Sub

    Private Sub BunifuFlatButton1_Click(sender As Object, e As EventArgs) Handles Button2.Click
        ListBox1.Items.Clear()
        File.Delete("C:\Windows\System32\drivers\etc\hosts")
        MsgBox("UnBlocked Success")
    End Sub

    Private Sub BunifuFlatButton2_Click(sender As Object, e As EventArgs) Handles Button3.Click
        ListBox1.Items.Remove(ListBox1.SelectedItem)
        MsgBox("Deleted Success")
    End Sub

    Private Sub BunifuFlatButton1_Click_1(sender As Object, e As EventArgs) Handles Button4.Click
        Dim lines() As String = IO.File.ReadAllLines("C:\Windows\System32\drivers\etc\hosts")
        ListBox1.Items.AddRange(lines)
        MsgBox("Read Success")
    End Sub

    Private Sub BunifuFlatButton1_Click_2(sender As Object, e As EventArgs) Handles BunifuFlatButton1.Click
        path = "C:\Windows\System32\drivers\etc\hosts"
        sw = New StreamWriter(path, True)
        Dim sitetoblock As String = (Environment.NewLine & "127.0.0.1 " & TextBox1.Text) 'has to be www.google.com | NOT: http://www.google.com/
        sw.Write(sitetoblock)
        sw.Close()
        MessageBox.Show("Site Blocked Please Restart The Browser")
    End Sub
End Class