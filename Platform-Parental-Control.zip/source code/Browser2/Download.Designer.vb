﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Download
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Download))
        Me.TXT_Nome = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TXT_Diretorio = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lb_Colar = New System.Windows.Forms.LinkLabel()
        Me.TXT_URL = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.IM = New System.Windows.Forms.ImageList(Me.components)
        Me.LV_Downloads = New System.Windows.Forms.ListView()
        Me.ColumnHeader1 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader2 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader3 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.btn_Download = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.btnProcurar = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.SuspendLayout()
        '
        'TXT_Nome
        '
        Me.TXT_Nome.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TXT_Nome.Location = New System.Drawing.Point(434, 39)
        Me.TXT_Nome.Name = "TXT_Nome"
        Me.TXT_Nome.Size = New System.Drawing.Size(158, 22)
        Me.TXT_Nome.TabIndex = 15
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Gold
        Me.Label3.Location = New System.Drawing.Point(431, 23)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(38, 13)
        Me.Label3.TabIndex = 14
        Me.Label3.Text = "Name"
        '
        'TXT_Diretorio
        '
        Me.TXT_Diretorio.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TXT_Diretorio.Location = New System.Drawing.Point(21, 80)
        Me.TXT_Diretorio.Name = "TXT_Diretorio"
        Me.TXT_Diretorio.Size = New System.Drawing.Size(571, 22)
        Me.TXT_Diretorio.TabIndex = 13
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Gold
        Me.Label2.Location = New System.Drawing.Point(18, 64)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(53, 13)
        Me.Label2.TabIndex = 12
        Me.Label2.Text = "Diretorio"
        '
        'lb_Colar
        '
        Me.lb_Colar.AutoSize = True
        Me.lb_Colar.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lb_Colar.ForeColor = System.Drawing.Color.Red
        Me.lb_Colar.LinkColor = System.Drawing.Color.Red
        Me.lb_Colar.Location = New System.Drawing.Point(375, 23)
        Me.lb_Colar.Name = "lb_Colar"
        Me.lb_Colar.Size = New System.Drawing.Size(41, 13)
        Me.lb_Colar.TabIndex = 11
        Me.lb_Colar.TabStop = True
        Me.lb_Colar.Text = "Copiar"
        '
        'TXT_URL
        '
        Me.TXT_URL.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TXT_URL.Location = New System.Drawing.Point(21, 39)
        Me.TXT_URL.Name = "TXT_URL"
        Me.TXT_URL.Size = New System.Drawing.Size(407, 22)
        Me.TXT_URL.TabIndex = 10
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Gold
        Me.Label1.Location = New System.Drawing.Point(18, 23)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(28, 13)
        Me.Label1.TabIndex = 9
        Me.Label1.Text = "URL"
        '
        'IM
        '
        Me.IM.ImageStream = CType(resources.GetObject("IM.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.IM.TransparentColor = System.Drawing.Color.Transparent
        Me.IM.Images.SetKeyName(0, "01.png")
        '
        'LV_Downloads
        '
        Me.LV_Downloads.BackColor = System.Drawing.Color.FromArgb(CType(CType(5, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(30, Byte), Integer))
        Me.LV_Downloads.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader1, Me.ColumnHeader2, Me.ColumnHeader3})
        Me.LV_Downloads.ForeColor = System.Drawing.Color.Aquamarine
        Me.LV_Downloads.LargeImageList = Me.ImageList1
        Me.LV_Downloads.Location = New System.Drawing.Point(88, 108)
        Me.LV_Downloads.Name = "LV_Downloads"
        Me.LV_Downloads.Size = New System.Drawing.Size(504, 400)
        Me.LV_Downloads.SmallImageList = Me.IM
        Me.LV_Downloads.TabIndex = 18
        Me.LV_Downloads.UseCompatibleStateImageBehavior = False
        Me.LV_Downloads.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader1
        '
        Me.ColumnHeader1.Text = "URL"
        Me.ColumnHeader1.Width = 250
        '
        'ColumnHeader2
        '
        Me.ColumnHeader2.Text = "Status"
        Me.ColumnHeader2.Width = 0
        '
        'ColumnHeader3
        '
        Me.ColumnHeader3.Text = "Size"
        Me.ColumnHeader3.Width = 250
        '
        'ImageList1
        '
        Me.ImageList1.ImageStream = CType(resources.GetObject("ImageList1.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Transparent
        Me.ImageList1.Images.SetKeyName(0, "animasi-loading-gif-7.gif")
        '
        'btn_Download
        '
        Me.btn_Download.Activecolor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(139, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.btn_Download.BackColor = System.Drawing.Color.Tomato
        Me.btn_Download.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_Download.BorderRadius = 0
        Me.btn_Download.ButtonText = "Download"
        Me.btn_Download.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_Download.DisabledColor = System.Drawing.Color.Gray
        Me.btn_Download.Font = New System.Drawing.Font("Franklin Gothic Medium", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Download.Iconcolor = System.Drawing.Color.Transparent
        Me.btn_Download.Iconimage = Nothing
        Me.btn_Download.Iconimage_right = Nothing
        Me.btn_Download.Iconimage_right_Selected = Nothing
        Me.btn_Download.Iconimage_Selected = Nothing
        Me.btn_Download.IconMarginLeft = 0
        Me.btn_Download.IconMarginRight = 0
        Me.btn_Download.IconRightVisible = True
        Me.btn_Download.IconRightZoom = 0R
        Me.btn_Download.IconVisible = True
        Me.btn_Download.IconZoom = 90.0R
        Me.btn_Download.IsTab = False
        Me.btn_Download.Location = New System.Drawing.Point(599, 36)
        Me.btn_Download.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btn_Download.Name = "btn_Download"
        Me.btn_Download.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(125, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btn_Download.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(205, Byte), Integer), CType(CType(81, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btn_Download.OnHoverTextColor = System.Drawing.Color.White
        Me.btn_Download.selected = False
        Me.btn_Download.Size = New System.Drawing.Size(77, 25)
        Me.btn_Download.TabIndex = 25
        Me.btn_Download.Text = "Download"
        Me.btn_Download.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_Download.Textcolor = System.Drawing.Color.White
        Me.btn_Download.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'btnProcurar
        '
        Me.btnProcurar.Activecolor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(139, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.btnProcurar.BackColor = System.Drawing.Color.Tomato
        Me.btnProcurar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnProcurar.BorderRadius = 0
        Me.btnProcurar.ButtonText = "Review"
        Me.btnProcurar.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnProcurar.DisabledColor = System.Drawing.Color.Gray
        Me.btnProcurar.Font = New System.Drawing.Font("Franklin Gothic Medium", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnProcurar.Iconcolor = System.Drawing.Color.Transparent
        Me.btnProcurar.Iconimage = Nothing
        Me.btnProcurar.Iconimage_right = Nothing
        Me.btnProcurar.Iconimage_right_Selected = Nothing
        Me.btnProcurar.Iconimage_Selected = Nothing
        Me.btnProcurar.IconMarginLeft = 0
        Me.btnProcurar.IconMarginRight = 0
        Me.btnProcurar.IconRightVisible = True
        Me.btnProcurar.IconRightZoom = 0R
        Me.btnProcurar.IconVisible = True
        Me.btnProcurar.IconZoom = 90.0R
        Me.btnProcurar.IsTab = False
        Me.btnProcurar.Location = New System.Drawing.Point(599, 80)
        Me.btnProcurar.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnProcurar.Name = "btnProcurar"
        Me.btnProcurar.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(125, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnProcurar.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(205, Byte), Integer), CType(CType(81, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnProcurar.OnHoverTextColor = System.Drawing.Color.White
        Me.btnProcurar.selected = False
        Me.btnProcurar.Size = New System.Drawing.Size(77, 29)
        Me.btnProcurar.TabIndex = 26
        Me.btnProcurar.Text = "Review"
        Me.btnProcurar.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btnProcurar.Textcolor = System.Drawing.Color.White
        Me.btnProcurar.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'Download
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(5, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(30, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(685, 520)
        Me.Controls.Add(Me.btnProcurar)
        Me.Controls.Add(Me.btn_Download)
        Me.Controls.Add(Me.LV_Downloads)
        Me.Controls.Add(Me.TXT_Nome)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.TXT_Diretorio)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.lb_Colar)
        Me.Controls.Add(Me.TXT_URL)
        Me.Controls.Add(Me.Label1)
        Me.ForeColor = System.Drawing.Color.Gold
        Me.Name = "Download"
        Me.Text = "Download File POKO"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TXT_Nome As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents TXT_Diretorio As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents lb_Colar As LinkLabel
    Friend WithEvents TXT_URL As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents IM As ImageList
    Friend WithEvents LV_Downloads As ListView
    Friend WithEvents ColumnHeader1 As ColumnHeader
    Friend WithEvents ColumnHeader2 As ColumnHeader
    Friend WithEvents ColumnHeader3 As ColumnHeader
    Friend WithEvents ImageList1 As ImageList
    Friend WithEvents btn_Download As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents btnProcurar As Bunifu.Framework.UI.BunifuFlatButton
End Class
