﻿Public Class Form3
    Dim TR As System.IO.TextReader
    Dim TW As System.IO.TextWriter
    Dim FileName As String = "C:\Program Files\pw.txt"

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If Textbox1.Text = "" Then
            MessageBox.Show("Please fill username")
        ElseIf Textbox2.Text = "" Then
            MessageBox.Show("Please fill password")
        Else
            TW = System.IO.File.CreateText(FileName)
            TW.Write(Textbox1.Text & " " & Textbox2.Text)
            TW.Close()
            MessageBox.Show("Username & Password Changed")
            Textbox1.Text = ""
            Textbox2.Text = ""
            Close()

        End If
    End Sub

    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button1k_Click(sender As Object, e As EventArgs) Handles Button1k.Click
        If Textbox1.Text = "" Then
            MessageBox.Show("Please fill username")
        ElseIf Textbox2.Text = "" Then
            MessageBox.Show("Please fill password")
        Else
            TW = System.IO.File.CreateText(FileName)
            TW.Write(Textbox1.Text & " " & Textbox2.Text)
            TW.Close()
            MessageBox.Show("Username & Password Changed")
            Textbox1.Text = ""
            Textbox2.Text = ""
            Hide()
        End If
    End Sub
End Class