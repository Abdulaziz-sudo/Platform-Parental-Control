﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Button1k = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Textbox1 = New Bunifu.Framework.UI.BunifuMetroTextbox()
        Me.Textbox2 = New Bunifu.Framework.UI.BunifuMetroTextbox()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Button1k
        '
        Me.Button1k.Activecolor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(139, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.Button1k.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(125, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Button1k.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button1k.BorderRadius = 0
        Me.Button1k.ButtonText = "Login"
        Me.Button1k.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button1k.DisabledColor = System.Drawing.Color.Gray
        Me.Button1k.Font = New System.Drawing.Font("Franklin Gothic Medium", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1k.Iconcolor = System.Drawing.Color.Transparent
        Me.Button1k.Iconimage = Nothing
        Me.Button1k.Iconimage_right = Nothing
        Me.Button1k.Iconimage_right_Selected = Nothing
        Me.Button1k.Iconimage_Selected = Nothing
        Me.Button1k.IconMarginLeft = 0
        Me.Button1k.IconMarginRight = 0
        Me.Button1k.IconRightVisible = True
        Me.Button1k.IconRightZoom = 0R
        Me.Button1k.IconVisible = True
        Me.Button1k.IconZoom = 90.0R
        Me.Button1k.IsTab = False
        Me.Button1k.Location = New System.Drawing.Point(41, 502)
        Me.Button1k.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Button1k.Name = "Button1k"
        Me.Button1k.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(125, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Button1k.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(205, Byte), Integer), CType(CType(81, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Button1k.OnHoverTextColor = System.Drawing.Color.White
        Me.Button1k.selected = False
        Me.Button1k.Size = New System.Drawing.Size(322, 58)
        Me.Button1k.TabIndex = 11
        Me.Button1k.Text = "Login"
        Me.Button1k.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Button1k.Textcolor = System.Drawing.Color.White
        Me.Button1k.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'PictureBox3
        '
        Me.PictureBox3.Image = Global.Browser2.My.Resources.Resources.forgot_password_lock_security_3ea684c2761c8e4b_512x512
        Me.PictureBox3.Location = New System.Drawing.Point(41, 358)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(64, 44)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox3.TabIndex = 10
        Me.PictureBox3.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = Global.Browser2.My.Resources.Resources.businessman_xxl
        Me.PictureBox2.Location = New System.Drawing.Point(41, 259)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(64, 44)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 9
        Me.PictureBox2.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.Browser2.My.Resources.Resources.EngagedParentsIcon
        Me.PictureBox1.Location = New System.Drawing.Point(89, 52)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(236, 163)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 5
        Me.PictureBox1.TabStop = False
        '
        'Textbox1
        '
        Me.Textbox1.BorderColorFocused = System.Drawing.Color.FromArgb(CType(CType(205, Byte), Integer), CType(CType(81, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Textbox1.BorderColorIdle = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(125, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Textbox1.BorderColorMouseHover = System.Drawing.Color.FromArgb(CType(CType(205, Byte), Integer), CType(CType(81, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Textbox1.BorderThickness = 3
        Me.Textbox1.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.Textbox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.Textbox1.ForeColor = System.Drawing.Color.White
        Me.Textbox1.isPassword = False
        Me.Textbox1.Location = New System.Drawing.Point(123, 259)
        Me.Textbox1.Margin = New System.Windows.Forms.Padding(4)
        Me.Textbox1.Name = "Textbox1"
        Me.Textbox1.Size = New System.Drawing.Size(240, 44)
        Me.Textbox1.TabIndex = 14
        Me.Textbox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'Textbox2
        '
        Me.Textbox2.BorderColorFocused = System.Drawing.Color.FromArgb(CType(CType(205, Byte), Integer), CType(CType(81, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Textbox2.BorderColorIdle = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(125, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Textbox2.BorderColorMouseHover = System.Drawing.Color.FromArgb(CType(CType(205, Byte), Integer), CType(CType(81, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Textbox2.BorderThickness = 3
        Me.Textbox2.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.Textbox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.Textbox2.ForeColor = System.Drawing.Color.White
        Me.Textbox2.isPassword = True
        Me.Textbox2.Location = New System.Drawing.Point(123, 358)
        Me.Textbox2.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Textbox2.Name = "Textbox2"
        Me.Textbox2.Size = New System.Drawing.Size(240, 44)
        Me.Textbox2.TabIndex = 15
        Me.Textbox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(5, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(30, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(422, 612)
        Me.Controls.Add(Me.Textbox2)
        Me.Controls.Add(Me.Textbox1)
        Me.Controls.Add(Me.Button1k)
        Me.Controls.Add(Me.PictureBox3)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.PictureBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Form2"
        Me.Text = "Form2"
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents Button1k As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents Textbox1 As Bunifu.Framework.UI.BunifuMetroTextbox
    Friend WithEvents Textbox2 As Bunifu.Framework.UI.BunifuMetroTextbox
End Class
