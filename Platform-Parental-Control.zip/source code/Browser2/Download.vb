﻿
Imports System
        Imports System.Net
Public Class Download
    Dim LogsItem As New Dictionary(Of WebClient, ListViewItem)

    Private Sub lb_Colar_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles lb_Colar.LinkClicked
        TXT_URL.Text = Clipboard.GetText.ToString
    End Sub

    Private Sub btnProcurar_Click(sender As Object, e As EventArgs)
        Dim I As New FolderBrowserDialog
        I.RootFolder = Environment.SpecialFolder.Desktop
        I.ShowNewFolderButton = True
        If I.ShowDialog = Windows.Forms.DialogResult.OK Then
            TXT_Diretorio.Text = I.SelectedPath
        End If
    End Sub

    Private Sub IniciarDownload(ByVal URL As Uri, ByVal Diretorio As String, ByVal Nome As String)
        Try

            Dim NewItem As New ListViewItem

            NewItem.Text = URL.ToString

            NewItem.SubItems.Add("")

            NewItem.SubItems.Add("0,00 KB/0,00 KB")

            NewItem.ImageIndex = 0

            LV_Downloads.Items.Add(NewItem)
            Using I As New WebClient

                AddHandler I.DownloadProgressChanged, AddressOf Carregando

                I.DownloadFileTaskAsync(URL, TXT_Diretorio.Text & "\" & TXT_Nome.Text)

                LogsItem.Add(I, NewItem)

            End Using

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub Carregando(ByVal R As Object, ByVal e As DownloadProgressChangedEventArgs)
        On Error Resume Next
        LV_Downloads.Items(LogsItem.Item(R).Index).SubItems(2).Text = StringFormat(e.BytesReceived) & "/" & StringFormat(e.TotalBytesToReceive)
    End Sub

    Private Function StringFormat(Tamanho) As String
        Try
            If Tamanho > 1000000000.0 Then
                Return Format(Tamanho / 1024 / 1024 / 1024, "#0.00") & " GB"
            ElseIf Tamanho > 1024 Then
                Return Format(Tamanho / 1024 / 1024, "#0.00") & " MB"
            ElseIf Tamanho < 1024 Then
                Return Format(Tamanho / 1024 / 1024, "#0.00") & " KB"
            Else
                Return Format(Tamanho, "#0.00") & " KB"
            End If
        Catch ex As Exception
            Return Format(Tamanho, "#0.00") & " KB"
        End Try
    End Function



    Private Sub btn_Download_Click(sender As Object, e As EventArgs)
        IniciarDownload(New Uri(TXT_URL.Text), TXT_Diretorio.Text, TXT_Nome.Text)
    End Sub

    Private Sub Download_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub BunifuFlatButton3_Click(sender As Object, e As EventArgs) Handles btn_Download.Click
        IniciarDownload(New Uri(TXT_URL.Text), TXT_Diretorio.Text, TXT_Nome.Text)
    End Sub

    Private Sub BunifuFlatButton1_Click(sender As Object, e As EventArgs) Handles btnProcurar.Click
        Dim I As New FolderBrowserDialog
        I.RootFolder = Environment.SpecialFolder.Desktop
        I.ShowNewFolderButton = True
        If I.ShowDialog = Windows.Forms.DialogResult.OK Then
            TXT_Diretorio.Text = I.SelectedPath
        End If
    End Sub
End Class