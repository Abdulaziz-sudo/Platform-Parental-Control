﻿Imports System.IO
Public Class alarm
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Me.Label1.Text = TimeOfDay


        For Each item As ListViewItem In Me.ListView1.Items
            If item.SubItems(0).Text = Me.Label1.Text Then
                System.Diagnostics.Process.Start("alarm.mp3")
                Dim myprocess() As Process = System.Diagnostics.Process.GetProcessesByName("poko")
                For Each mykill As Process In myprocess
                    mykill.Kill()
                Next
            End If
        Next
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs)
        ListView1.Items.Clear()
        File.Delete("C:\browser\Times.txt")

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs)

        Dim myAlarmTime As String

        myAlarmTime = InputBox("please add the time of alarm")

        Dim Lvitem As ListViewItem
        Lvitem = Me.ListView1.Items.Add(myAlarmTime)
        Dim file As System.IO.StreamWriter
        file = My.Computer.FileSystem.OpenTextFileWriter("C:\browser\Times.txt", True)
        file.WriteLine(myAlarmTime)
        file.Close()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs)
        Hide()
    End Sub

    Private Sub ListView1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListView1.SelectedIndexChanged
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs)

        Dim data As String() = IO.File.ReadAllLines("C:\browser\Times.txt")
        For i As Integer = 0 To data.Count - 1
            ListView1.Items.Add(data(i))
        Next
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs)
        Me.ListView1.SelectedItems("C:\browser\Times.txt").Remove()
    End Sub

    Private Sub alarm_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub BunifuFlatButton1_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton1.Click
        Dim myAlarmTime As String

        myAlarmTime = InputBox("please add the time of alarm")

        Dim Lvitem As ListViewItem
        Lvitem = Me.ListView1.Items.Add(myAlarmTime)
        Dim file As System.IO.StreamWriter
        file = My.Computer.FileSystem.OpenTextFileWriter("C:\browser\Times.txt", True)
        file.WriteLine(myAlarmTime)
        file.Close()
    End Sub

    Private Sub BunifuFlatButton3_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Dim data As String() = IO.File.ReadAllLines("C:\browser\Times.txt")
        For i As Integer = 0 To data.Count - 1
            ListView1.Items.Add(data(i))
        Next
    End Sub

    Private Sub BunifuFlatButton2_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton2.Click
        ListView1.Items.Clear()
        File.Delete("C:\browser\Times.txt")
    End Sub

    Private Sub Button2_Click_1(sender As Object, e As EventArgs) Handles Button2.Click
        Hide()
    End Sub
End Class