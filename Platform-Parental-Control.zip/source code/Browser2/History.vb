﻿Imports System.ComponentModel
Imports System.IO


Public Class History
    Public Event DocumentCopleted()

    Private Sub History_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        ' Never Lose History
        e.Cancel = True
        Me.Visible = False

        File.Delete("C:\browser\history.txt")

        For Each link As String In lstHistory.Items
            File.AppendAllText("C:\browser\history.txt", link & vbNewLine)

        Next
    End Sub

    Private Sub btnDeleteAll_Click(sender As Object, e As EventArgs)
        lstHistory.Items.Clear()
        File.Delete("C:\browser\history.txt")
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs)
        File.Delete("C:\browser\history.txt")

        For Each link As String In lstHistory.Items
            File.AppendAllText("C:\browser\history.txt", link & vbNewLine)

        Next
        Me.Visible = False
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs)
        lstHistory.Items.Remove(lstHistory.SelectedItem)
    End Sub
    Private Sub webBrowserDocCompl() Handles Me.DocumentCopleted


    End Sub

    Private Sub History_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub lstHistory_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lstHistory.SelectedIndexChanged

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        lstHistory.Items.Clear()
        File.Delete("C:\browser\history.txt")
    End Sub

    Private Sub BunifuFlatButton1_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton1.Click
        lstHistory.Items.Remove(lstHistory.SelectedItem)
    End Sub

    Private Sub BunifuFlatButton2_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton2.Click
        File.Delete("C:\browser\history.txt")

        For Each link As String In lstHistory.Items
            File.AppendAllText("C:\browser\history.txt", link & vbNewLine)

        Next
        Me.Visible = False
    End Sub
End Class