﻿Public Class Form2
    Dim TR As System.IO.TextReader
    Dim TW As System.IO.TextWriter
    Dim FileName As String = "C:\Program Files\pw.txt"
    Dim temp As String
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If System.IO.File.Exists(FileName) = False Then
            TW = System.IO.File.CreateText(FileName)
            TW.Write("admin" & " " & "123456")
            TW.Close()
        End If
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        TR = System.IO.File.OpenText(FileName)
        temp = TR.ReadToEnd
        TR.Close()
        If temp = Textbox1.Text & " " & Textbox2.Text Then
            Textbox1.Text = ""
            Textbox2.Text = ""
            Browser.Show()
            Hide()
        Else
            eroor.Show()
        End If
    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles Button1k.Click
        TR = System.IO.File.OpenText(FileName)
        temp = TR.ReadToEnd
        TR.Close()
        If temp = Textbox1.Text & " " & Textbox2.Text Then
            Textbox1.Text = ""
            Textbox2.Text = ""
            Browser.Show()
            Hide()
        Else
            eroor.Show()
        End If
    End Sub
End Class