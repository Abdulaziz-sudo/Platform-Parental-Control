﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FatherLogin2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Button1 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.Button2 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.Button6 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.Button3 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.Button5 = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.Button4 = New Bunifu.Framework.UI.BunifuFlatButton()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.Browser2.My.Resources.Resources.User_Icon_256
        Me.PictureBox1.Location = New System.Drawing.Point(12, 39)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(216, 268)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 6
        Me.PictureBox1.TabStop = False
        '
        'Button1
        '
        Me.Button1.Activecolor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(139, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.Button1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(125, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button1.BorderRadius = 0
        Me.Button1.ButtonText = "History"
        Me.Button1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button1.DisabledColor = System.Drawing.Color.Gray
        Me.Button1.Font = New System.Drawing.Font("Franklin Gothic Medium", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Iconcolor = System.Drawing.Color.Transparent
        Me.Button1.Iconimage = Nothing
        Me.Button1.Iconimage_right = Nothing
        Me.Button1.Iconimage_right_Selected = Nothing
        Me.Button1.Iconimage_Selected = Nothing
        Me.Button1.IconMarginLeft = 0
        Me.Button1.IconMarginRight = 0
        Me.Button1.IconRightVisible = True
        Me.Button1.IconRightZoom = 0R
        Me.Button1.IconVisible = True
        Me.Button1.IconZoom = 90.0R
        Me.Button1.IsTab = False
        Me.Button1.Location = New System.Drawing.Point(254, 25)
        Me.Button1.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Button1.Name = "Button1"
        Me.Button1.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(125, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Button1.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(205, Byte), Integer), CType(CType(81, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Button1.OnHoverTextColor = System.Drawing.Color.White
        Me.Button1.selected = False
        Me.Button1.Size = New System.Drawing.Size(122, 74)
        Me.Button1.TabIndex = 12
        Me.Button1.Text = "History"
        Me.Button1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Button1.Textcolor = System.Drawing.Color.White
        Me.Button1.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'Button2
        '
        Me.Button2.Activecolor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(139, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.Button2.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(125, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button2.BorderRadius = 0
        Me.Button2.ButtonText = "Block Website"
        Me.Button2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button2.DisabledColor = System.Drawing.Color.Gray
        Me.Button2.Font = New System.Drawing.Font("Franklin Gothic Medium", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Iconcolor = System.Drawing.Color.Transparent
        Me.Button2.Iconimage = Nothing
        Me.Button2.Iconimage_right = Nothing
        Me.Button2.Iconimage_right_Selected = Nothing
        Me.Button2.Iconimage_Selected = Nothing
        Me.Button2.IconMarginLeft = 0
        Me.Button2.IconMarginRight = 0
        Me.Button2.IconRightVisible = True
        Me.Button2.IconRightZoom = 0R
        Me.Button2.IconVisible = True
        Me.Button2.IconZoom = 90.0R
        Me.Button2.IsTab = False
        Me.Button2.Location = New System.Drawing.Point(424, 25)
        Me.Button2.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Button2.Name = "Button2"
        Me.Button2.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(125, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Button2.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(205, Byte), Integer), CType(CType(81, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Button2.OnHoverTextColor = System.Drawing.Color.White
        Me.Button2.selected = False
        Me.Button2.Size = New System.Drawing.Size(110, 74)
        Me.Button2.TabIndex = 13
        Me.Button2.Text = "Block Website"
        Me.Button2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Button2.Textcolor = System.Drawing.Color.White
        Me.Button2.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'Button6
        '
        Me.Button6.Activecolor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(139, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.Button6.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(125, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Button6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button6.BorderRadius = 0
        Me.Button6.ButtonText = "Change Password"
        Me.Button6.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button6.DisabledColor = System.Drawing.Color.Gray
        Me.Button6.Font = New System.Drawing.Font("Franklin Gothic Medium", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button6.Iconcolor = System.Drawing.Color.Transparent
        Me.Button6.Iconimage = Nothing
        Me.Button6.Iconimage_right = Nothing
        Me.Button6.Iconimage_right_Selected = Nothing
        Me.Button6.Iconimage_Selected = Nothing
        Me.Button6.IconMarginLeft = 0
        Me.Button6.IconMarginRight = 0
        Me.Button6.IconRightVisible = True
        Me.Button6.IconRightZoom = 0R
        Me.Button6.IconVisible = True
        Me.Button6.IconZoom = 90.0R
        Me.Button6.IsTab = False
        Me.Button6.Location = New System.Drawing.Point(254, 253)
        Me.Button6.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Button6.Name = "Button6"
        Me.Button6.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(125, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Button6.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(205, Byte), Integer), CType(CType(81, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Button6.OnHoverTextColor = System.Drawing.Color.White
        Me.Button6.selected = False
        Me.Button6.Size = New System.Drawing.Size(122, 74)
        Me.Button6.TabIndex = 16
        Me.Button6.Text = "Change Password"
        Me.Button6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Button6.Textcolor = System.Drawing.Color.White
        Me.Button6.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'Button3
        '
        Me.Button3.Activecolor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(139, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.Button3.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(125, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button3.BorderRadius = 0
        Me.Button3.ButtonText = "Shutdown computer in a specific time"
        Me.Button3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button3.DisabledColor = System.Drawing.Color.Gray
        Me.Button3.Font = New System.Drawing.Font("Franklin Gothic Medium", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.Iconcolor = System.Drawing.Color.Transparent
        Me.Button3.Iconimage = Nothing
        Me.Button3.Iconimage_right = Nothing
        Me.Button3.Iconimage_right_Selected = Nothing
        Me.Button3.Iconimage_Selected = Nothing
        Me.Button3.IconMarginLeft = 0
        Me.Button3.IconMarginRight = 0
        Me.Button3.IconRightVisible = True
        Me.Button3.IconRightZoom = 0R
        Me.Button3.IconVisible = True
        Me.Button3.IconZoom = 90.0R
        Me.Button3.IsTab = False
        Me.Button3.Location = New System.Drawing.Point(254, 150)
        Me.Button3.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Button3.Name = "Button3"
        Me.Button3.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(125, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Button3.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(205, Byte), Integer), CType(CType(81, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Button3.OnHoverTextColor = System.Drawing.Color.White
        Me.Button3.selected = False
        Me.Button3.Size = New System.Drawing.Size(122, 74)
        Me.Button3.TabIndex = 17
        Me.Button3.Text = "Shutdown computer in a specific time"
        Me.Button3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Button3.Textcolor = System.Drawing.Color.White
        Me.Button3.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'Button5
        '
        Me.Button5.Activecolor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(139, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.Button5.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(125, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Button5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button5.BorderRadius = 0
        Me.Button5.ButtonText = "Exit"
        Me.Button5.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button5.DisabledColor = System.Drawing.Color.Gray
        Me.Button5.Font = New System.Drawing.Font("Franklin Gothic Medium", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button5.Iconcolor = System.Drawing.Color.Transparent
        Me.Button5.Iconimage = Nothing
        Me.Button5.Iconimage_right = Nothing
        Me.Button5.Iconimage_right_Selected = Nothing
        Me.Button5.Iconimage_Selected = Nothing
        Me.Button5.IconMarginLeft = 0
        Me.Button5.IconMarginRight = 0
        Me.Button5.IconRightVisible = True
        Me.Button5.IconRightZoom = 0R
        Me.Button5.IconVisible = True
        Me.Button5.IconZoom = 90.0R
        Me.Button5.IsTab = False
        Me.Button5.Location = New System.Drawing.Point(424, 253)
        Me.Button5.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Button5.Name = "Button5"
        Me.Button5.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(125, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Button5.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(205, Byte), Integer), CType(CType(81, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Button5.OnHoverTextColor = System.Drawing.Color.White
        Me.Button5.selected = False
        Me.Button5.Size = New System.Drawing.Size(110, 74)
        Me.Button5.TabIndex = 18
        Me.Button5.Text = "Exit"
        Me.Button5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Button5.Textcolor = System.Drawing.Color.White
        Me.Button5.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'Button4
        '
        Me.Button4.Activecolor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(139, Byte), Integer), CType(CType(87, Byte), Integer))
        Me.Button4.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(125, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Button4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button4.BorderRadius = 0
        Me.Button4.ButtonText = "Alarm"
        Me.Button4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button4.DisabledColor = System.Drawing.Color.Gray
        Me.Button4.Font = New System.Drawing.Font("Franklin Gothic Medium", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.Iconcolor = System.Drawing.Color.Transparent
        Me.Button4.Iconimage = Nothing
        Me.Button4.Iconimage_right = Nothing
        Me.Button4.Iconimage_right_Selected = Nothing
        Me.Button4.Iconimage_Selected = Nothing
        Me.Button4.IconMarginLeft = 0
        Me.Button4.IconMarginRight = 0
        Me.Button4.IconRightVisible = True
        Me.Button4.IconRightZoom = 0R
        Me.Button4.IconVisible = True
        Me.Button4.IconZoom = 90.0R
        Me.Button4.IsTab = False
        Me.Button4.Location = New System.Drawing.Point(424, 149)
        Me.Button4.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Button4.Name = "Button4"
        Me.Button4.Normalcolor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(125, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Button4.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(205, Byte), Integer), CType(CType(81, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Button4.OnHoverTextColor = System.Drawing.Color.White
        Me.Button4.selected = False
        Me.Button4.Size = New System.Drawing.Size(110, 74)
        Me.Button4.TabIndex = 19
        Me.Button4.Text = "Alarm"
        Me.Button4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Button4.Textcolor = System.Drawing.Color.White
        Me.Button4.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'FatherLogin2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(5, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(30, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(565, 341)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button6)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.PictureBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Name = "FatherLogin2"
        Me.Text = "FatherLogin2"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Button1 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents Button2 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents Button6 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents Button3 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents Button5 As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents Button4 As Bunifu.Framework.UI.BunifuFlatButton
End Class
